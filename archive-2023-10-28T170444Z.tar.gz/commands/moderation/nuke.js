module.exports = {
    name: "nuke",
    type: "messageCreate",
    code: 
    `$onlyIf[$hasPerms[$guildID;$authorID;Administrator];:Error:You Need Admin Permission In-Order To Use This Command] $setVar[channelname;$guildID;$channelName] $setVar[channeltype;$guildID;$channelType] $setVar[channeltopic;$guildID;$channelTopic] $setVar[channelcat;$guildID;$channelCategoryID]
$createChannel[$guildID;$getVar[channelname;$guildID];$getVar[channeltype;$guildID];;$getVar[channelcat;$guildID]]
$deleteChannels[$channelID]
`
}