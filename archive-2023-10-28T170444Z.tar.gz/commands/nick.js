module.exports = {
    name: "nick", // Not defining this creates a command that will be executed for every event fired of given type
    code: `$let[nick;$nickname[$guildID;$mentioned[0]]
    $setVar[supercookie;$mentioned[0];$sub[20;$getVar[supercookie;$authorID;0]]]
    $try[$membeSetNickname[$guildID;$mentioned[0];New nickname]]`,

    // $wait[300000]
    // $try[$membeSetNickname[$guildID;$mentioned[0];$get[nick]]] ,
    type: "messageCreate" // The event to act on
}