module.exports = {
    name: "work",
    type: "messageCreate",
    code:  `$let[zdid;Work-$authorID]
$let[duration;$parseString[6h]]

$let[zdleft;$math[$getVar[$get[zdid];] - $getTimestamp]]

$if[$get[zdleft] > 0;
    $sendMessage[$channelID;Hey! Don't be greedy. You still have $parseMS[$get[zdleft]] until you can work again smh]
    $stop
;
    $setVar[$get[zdid];;$math[$getTimestamp + $get[duration]]]
]

$let[rare;$randomNumber[0;11]]
$let[cookieamount;$randomNumber[0;20]]
        $let[supercookieamount;$randomNumber[0;4]]

        $if[$get[rare]==10;$setVar[supercookie;$authorID;$sum[$getVar[supercookie;$authorID];$get[supercookieamont]]];$setVar[cookie;$authorID;$sum[$getVar[cookie;$authorID];$get[cookieamount]]]] <@$authorID> Claimed some $if[$get[rare]==10;Super Cookie;Cookie]`
}