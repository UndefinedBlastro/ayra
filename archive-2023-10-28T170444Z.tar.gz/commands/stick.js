module.exports = {
    name: "stick",
    type: "messageCreate",
    code: `
    $function[$setVar[stickd;$channelID;$sendMessage[$channelID;$message;true]]
$setVar[stickym;$channelID;$message]] 
    `,
    unprefixed: false

}