module.exports = {
    name: "feedback",
    type: "messageCreate",
    code: `
    $sendMessage[$channelID[♡︱feedback];$title[Feedback by $username] $description[$message] $footer[$username;$userAvatar[$authorID]] $color[#c1baff]]
    `
 }