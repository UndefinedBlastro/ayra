module.exports = {
    name: "grow",
    type: "messageCreate",
    code:`
    ㅤ
        We have now $guildMemberCount Members!!
        
        Server has $guildBoostCount Boosts!!`,
    unprefixed: true

}