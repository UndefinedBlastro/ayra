module.exports = {
    name: "uwu",
    aliases: ["UwU", "Uwu", "Uwu", "uwu", "UWu", "UWU", "uWu", "uWU", "uwU"],
    type: "messageCreate",
    code:`E-girl Moment`,
    unprefixed: true

}