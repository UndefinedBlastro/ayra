module.exports = {
    name: "",
    type: "guildMemberAdd",
    code:`  $sendMessage[$channelID[✉︱general];$title[Welcome to Ayra Cafe $username <a:exclamation_mark:1160909279788810322>] $description[
        . Chat with us!
        . Boost us!
        . Check out [gws\\](https://discordapp.com/channels/982931539941818408/1000422092300353636) !!]
        $footer[$username;$userAvatar[$authorID]] $color[#c1baff] $image[https://i.imgur.com/GUEUhHv.gif
]  Welcome, <@$authorID> ! ]`,
    unprefixed: false

}