module.exports = {
    name: "",
    type: "userUpdate",
    code:`$onlyIf[$hasRoles[982931539941818408;$authorID;1061637541662568588]]
$sendMessage[983984426172178444;Thank you <@$authorID>!!$author[$userDisplayName[$authorID];$userAvatar] $description[Thank you for voting <@$authorID>!]$footer[$username;$userAvatar]$color[#c1baff] $image[https://i.imgur.com/GUEUhHv.gif]]
`,
    unprefixed: true

}