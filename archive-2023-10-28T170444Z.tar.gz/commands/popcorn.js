module.exports = {
    name: "popcorn",
    type: "messageCreate",
    code:`<:dicks:1163141960190660779>`,
    unprefixed: true

}